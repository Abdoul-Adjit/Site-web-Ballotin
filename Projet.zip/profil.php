<!DOCTYPE html>
<html>
    <head>
        <title>Mon profil</title>
        <meta charset="UTF-8" />
    </head>
    <body>
        <table border="1">
        <tr>
            <th colspan="4">Vos votes précédents :</th>
        </tr>
        <tr>
            <th>Identifiant du vote</th>
            <th>Question posée</th>
            <th>Etat du vote</th>
            <th>Résultats</th>
        </tr>
        <?php
        session_start();
        if(isset($_SESSION['id'])) {
            echo "<h1>Bonjour {$_SESSION['id']}</h1>";
            $users_file = file_get_contents("users.json");
            $users_data = json_decode($users_file,true);
            $users_votes = array();
            $state = "";
            foreach ($users_data as $value) {
                if($value['id'] === $_SESSION['id']) {
                    $users_votes = $value['votes'];
                }
            }
            for ($i=0; $i < sizeof($users_votes); $i++) {
                $vote_file = file_get_contents("./Votes/$users_votes[$i].json");
                $vote_data = json_decode($vote_file,true);
                if($vote_data['ongoing'] === true) {
                    $state = "En cours";
                }
                else {
                    $state = "Terminé";
                }
                echo "<tr><td>$users_votes[$i]</td><td>{$vote_data['question']}</td><td>$state</td><td><a href=\"http://localhost/Projet/resultat.php/?id={$users_votes[$i]}\">Vers résultat</a></td></tr>"; 
                // RAJOUTER UNE CASE ETAT DU VOTE
            }
            //RAJOUTER UN BOUTON CREER UN NVEAU VOTE + VERS ACCUIEL + DECONNEXION
        }
        else {
            header("Location: http://localhost/Projet/login.php");
        }
        ?>
        </table>
    </body>
</html>