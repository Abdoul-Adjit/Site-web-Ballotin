<!DOCTYPE html>
<html>
<head>
	<title>New Vote</title>
	<link rel="stylesheet" type="text/css" href="new-vote-style.css">
</head>
<body>
	<div class="content">
		<p class="page_title">Créer un nouveau scrutin</p>
		<form class="new_vote_form" action method="post">
		<p class="titre_partie">Question : </p>
			<?php
			//Modifer de sorte que les questions déjà écrites restes et les propositions déjà écrites aussi
				if(!isset($_POST['question'])) $_POST['question']="";
				if($_POST['question']!=="") {
					echo '<input type="text" name="question" value="'.$_POST['question'].'" />';
				}
				else {
					echo '<input type="text" class="question_form" name="question" placeholder="Question..." />';
				}
			?>
			<input type="submit" name="action" value="Ajouter" />
			<input type="submit" name="action" value="Enlever" /></br>
			<p class="titre_partie">Réponses : </p>
<!--<input type="text" class="answer_form" name="answer_1" /></br>
			<input type="text" class="answer_form" name="answer_2" /></br>-->
		<?php
			session_start();
			if(!isset($_POST["action"])) {
				$_POST["action"] = "null";
			}
			$id = $_GET['id'];
			$check = true;
			$vote_json =  file_get_contents("./Votes/$id.json");
			$data = json_decode($vote_json,true);
			if($_POST["action"] === "Ajouter") {
				$data["nb_answers"]++;
				$encoded_json = json_encode($data,JSON_PRETTY_PRINT);
				file_put_contents("./Votes/$id.json",$encoded_json);
			}
			elseif($_POST["action"] === "Enlever" and $data["nb_answers"] > 2) {
				$data["nb_answers"]--;
				$encoded_json = json_encode($data,JSON_PRETTY_PRINT);
				file_put_contents("./Votes/$id.json",$encoded_json);
			}
			if(!isset($_POST["answer_1"])) $_POST["answer_1"]="";
			if(!isset($_POST["answer_2"])) $_POST["answer_2"]="";
			if($_POST["answer_1"]==="") $_POST["answer_1"] = "Oui";
			if($_POST["answer_2"]==="") $_POST["answer_2"] = "Non";
			for ($i=1; $i < $data["nb_answers"] + 1; $i++) {
				if(!isset($_POST["answer_$i"])) $_POST["answer_$i"]="";
				if($_POST["answer_$i"]!== "") {
					print('<input type="text" class="answer_form" name="answer_'.$i.'" value="'.$_POST["answer_$i"].'" ></br>');
				}
				else {
				print('<input type="text" class="answer_form" name="answer_'.$i.'" placeholder="Réponse n°'.$i.'" ></br>');
				}
			}
			echo '<input class="submit_button" type="submit" name="action" value="Créer" />';
		?>
		<div class="second_form">
			<?php
			print('<p class="second_title">Participants autorisés à voter (ou Anonyme <input type="submit" name="Anonyme" value="Oui"> <input type="submit" name="Anonyme" value="Non"> ) :</p>');
			if(!isset($_POST["Anonyme"])) {
				$_POST["Anonyme"] = "Non";
			}
			if($_POST["Anonyme"] === "Non")
			{
			print('
			<table>
				<tr>
					<th colspan="2">Identifiant</th>
				</tr>
				<tr>
					<td><input type="text" name="part_1" placeholder="Identifiant"/></td>
					<td><input type="submit" name="action" value="+"/> <input type="submit" name="action" value="-"/></td>
				</tr>');
				
					if($_POST['action'] === "+") {
						$data['nb_participant']++;
						$encoded_json = json_encode($data,JSON_PRETTY_PRINT);
						file_put_contents("./Votes/$id.json",$encoded_json);
					}
					elseif($_POST['action'] === "-" and $data['nb_participant']>1) {
						$data['nb_participant']--;
						$encoded_json = json_encode($data,JSON_PRETTY_PRINT);
						file_put_contents("./Votes/$id.json",$encoded_json);
					}
					for ($i=2; $i < $data['nb_participant']+1 ; $i++) { 
						echo "<tr><td><input type=\"text\" name=\"part_$i\" placeholder=\"Identifiant..\"/></td></tr>";
					}
				}
					if($_POST["action"] === "Créer") {
						for($i=1;$i < $data["nb_answers"] + 1; $i++) {
							if($_POST["answer_$i"]==="") {
								$check = false;
								break;
							}
						}
					}
					if($_POST["action"] === "Créer" and $check) {
						$fp = fopen('./Votes_results/'.$id.'_results.json','w');
						$ans = array();
						for ($i=1; $i < $data["nb_answers"]+1; $i++) { 
							$ans += array("result_answer_$i" => 0);
						}
						fwrite($fp,json_encode($ans,JSON_PRETTY_PRINT));
						fclose($fp);
						$data["question"] = $_POST["question"];
						for ($i=1; $i < $data["nb_answers"]+1; $i++) { 
							$data += array("answer_$i" => $_POST["answer_$i"]);
						}
						for($j=1;$j<$data['nb_participant'] +1 ; $j++) {
							print ($_POST["part_$j"]);
							array_push($data['participants'],$_POST["part_$j"]);
						}
						if($_POST['Anonyme'] === 'Oui') $data['open_to_all'] = true;
						elseif($_POST['Anonyme'] === 'Non') $data['open_to_all'] = false;
						file_put_contents("./Votes/$id.json",json_encode($data,JSON_PRETTY_PRINT));
						header("Location: http://localhost/Projet/vote_created.php?id={$_GET['id']}");
					}
					if($_POST["action"] === "Créer" and !$check) {
						echo "Merci de remplir les cases des réponses";
					}
				?>
			</table>
		</div>
		</form>
	</div>
</body>
</html>