<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
	<link rel="stylesheet" type="text/css" href="style_accueil.css">
</head>
<body>
	<header>
		<div class="login_block">
		<!--<p class="page_title">Accueil</p>-->
		<?php
			session_start();
			if(isset($_POST['disconnect'])) {
				unset($_SESSION['id']);
			}
			if(isset($_SESSION['id'])) {
				echo '<h3>Bonjour <a href="http://localhost/Projet/profil.php">'.$_SESSION['id'].'</a></h3>';
				echo '<form method="post"><input type="submit" name="disconnect" value="Se déconnecter"/></form>';
			}
			else {
				echo '<a href="http://localhost/Projet/login.php">
						<div class="login">
							<p>Se connecter / Sinscricre</p>	
						</div>
					</a>';
			}
		?>
		</div>
	</header>
	<div class="new_vote">
		<form method="post" action>	
			<input type="submit" name="action" value="Créer un scrutin" />
		</form>
	</div>
	<div class="join_a_vote">
		<form method="post" action>
			<input type="submit" name="action" value="Participer à un scruptin" id="join_a_vote_button" />
		</form>
	</div>
	<?php
				if(!isset($_POST["action"])) {
					$_POST["action"] = "null";
				}
				elseif ($_POST["action"] === "Participer à un scruptin") {
					echo '	<div class="go_to_vote">
								<form method="post" action>
									<input type="text" name="join_a_vote_input" placeholder="ID du vote" /></br>
									<input type="submit" name="action" value="Aller au vote">
								</form>
							</div>';
				}
				elseif ($_POST["action"] === "Aller au vote") {
					$vote_id = $_POST["join_a_vote_input"];
					$dir = './Votes';
					$dir_content = scandir($dir);
					$check = in_array("$vote_id.json",$dir_content);
					if($check){
						header("Location: vote.php/?id=$vote_id");
					}
					else {
						echo "<p class='go_to_vote'>Ce numéro de vote n'existe pas</p>";
					}
				}
				elseif($_POST["action"] === "Créer un scrutin") {
					$dir = './Votes';
					$check_for_name = scandir($dir);
					$available_name = sizeof($check_for_name);
					$fp = fopen('./Votes/'.$available_name.'.json', 'w');
					if(isset($_SESSION['id'])){
						$users_file = file_get_contents("users.json");
            			$users_data = json_decode($users_file,true);
						$modele = array("id_creator" => "{$_SESSION['id']}","vote_id" => $available_name,"question" => "", "nb_answers" => 2,"ongoing" => true,"nb_participant" => 1,
						"participants" => [],"open_to_all" => true);
						foreach ($users_data as &$value) {
							if($value['id'] === $_SESSION['id']) {
								array_push($value['votes'],$available_name);
								file_put_contents("users.json",json_encode($users_data,JSON_PRETTY_PRINT));
								break;
							}
						}
						
					}
					else {
					$modele = array("id_creator" => "anonyme","vote_id" => $available_name,"question" => "", "nb_answers" => 2,"ongoing" => true,"nb_participant" => 1,
					"participants" => [],"open_to_all" => true);
					}
					fwrite($fp, json_encode($modele,JSON_PRETTY_PRINT));
					fclose($fp);
					header("Location: new_vote.php?id=$available_name");
				}
			?>
	</a>
</body>
</html>