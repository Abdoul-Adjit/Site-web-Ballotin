<!DOCTYPE html>
<html>
<head>
	<title>Vote here</title>
	<link rel="stylesheet" href="style-new-vote.css">
</head>
<body>
	<div class="content">
	<?php
		session_start();
		$vote_id = $_GET['id'];
		$file = file_get_contents('./Votes/'.$vote_id.'.json');
		$tab = json_decode($file,true);
		if(($tab['ongoing'] === true and isset($_SESSION['id']) and in_array($_SESSION['id'],$tab['participants'])) or $tab['open_to_all']===true){
		$question = $tab['question'];
		echo "<h1>$question</h1>";
		echo '<form method="post" action="vote.php/?id='.$vote_id.'">';
		for ($i=1; $i < $tab["nb_answers"]+1; $i++) {
				$inter = $tab["answer_$i"];
				echo '<div class="choice">';
				echo '<input type="radio" name="answers" value="'.$i.'">';
				echo "<label>$inter</label><br/>";
				echo '</div>';
			}
		echo '<input type="submit" name="validate_vote" value="Valider le vote" class="validate">';
		if(!isset($_POST["validate_vote"])) $_POST["validate_vote"] = "null";
		if($_POST["validate_vote"] === "Valider le vote"){
			$result = $_POST["answers"];
			$fp = "./Votes_results/{$vote_id}_results.json";
			$result_file = file_get_contents($fp);
			$data_result = json_decode($result_file,true);
			$data_result["result_answer_$result"]++;
			file_put_contents($fp,json_encode($data_result,JSON_PRETTY_PRINT));
		}
		echo'</form>';
		}
		elseif(!isset($_SESSION['id']) or !in_array($_SESSION['id'],$tab['participants'])) {
			echo "<h3>Vous n'êtes pas autorisé à accéder à ce vote.</h3>";
		}
		else {
			echo "<h3>Ce vote est terminé, vous ne pouvez plus voter.</h3>";
		}
		?>
	</div>
</body>
</html>