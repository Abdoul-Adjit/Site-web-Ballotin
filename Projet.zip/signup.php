<!DOCTYPE html> 
<html>
    <header>
        <title>Login</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style_login.css">
    </header>
    <body>
        <div class="content">
        <h1>Sign Up</h1>
            <form method="POST">
                <input type="text" name="log_id" placeholder="Identifiant.."/><br/>
                <input type="password" name="pwd" placeholder="Mot de passe.."/><br/>
                <input type="password" name="confirm_pwd" placeholder="Confirmer le mot de passe.."/><br/>
                <input type="submit" name="action" value="Se connecter" /><br/>
                <?php
                    $fp = file_get_contents("users.json");
                    $users_data = json_decode($fp,true);
                    $check_id = true;
                    $check_mdp = false;
                    if(isset($_POST['action'])){
                        if($_POST['pwd'] === $_POST['confirm_pwd']) {
                            $check_mdp = true;
                        }
                        foreach ($users_data as $value) {
                            if($value['id'] === $_POST['log_id']) {
                                $check_id = false;
                                break;
                            }
                        }
                        if(!$check_id) {
                            echo "L'identifiant entré est déjà utilisé";
                        }
                        elseif(!$check_mdp) {
                            echo "Les mots de passe entrés sont différents.";
                        }
                        else {
                            $new_user = array('id' => $_POST['log_id'],'pwd' => $_POST['pwd'] );
                            array_push($users_data,$new_user);
                            file_put_contents('users.json',json_encode($users_data,JSON_PRETTY_PRINT));
                            echo "Vous êtes inscrit !";
                        }
                    }
                ?>
            </form>
            <h3>Si vous êtes inscrit : <a href="http://localhost/Projet/login.php">Se connecter</a></h3>
        </div>
    </body>
</html>