<!DOCTYPE html>
<html>
    <header>
        <meta charset="UTF-8">
        <title>Votre vote a été crée</title>
    </header>
    <body>
        <?php
            echo "<h1>Votre vote a été crée et possède le numéro : {$_GET['id']}</h1>";
            echo '<h3>Voici le lien pour y participer : <a href="http://localhost/Projet/vote.php?id='.$_GET['id'].'">http://localhost/Projet/vote.php?id='.$_GET['id'].'</a></h3>';
            echo '<h3>Voici le lien pour y voir les résultats : <a href="http://localhost/Projet/resultat.php?id='.$_GET['id'].'">http://localhost/Projet/resultat.php?id='.$_GET['id'].'</a></h3>';
            echo '<form method="post"><input type="submit" name="end_vote" value="Terminer le vote"/></form>';
            if(isset($_POST['end_vote'])) {
                $vote_id = $_GET['id'];
		        $file = file_get_contents('./Votes/'.$vote_id.'.json');
		        $data = json_decode($file,true);
                $data['ongoing'] = false;
                file_put_contents('./Votes/'.$vote_id.'.json',json_encode($data,JSON_PRETTY_PRINT));
            }
        ?>
    </body>
</html>