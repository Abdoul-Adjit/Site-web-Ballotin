<!DOCTYPE html>
<html>
    <header>
        <meta charset="UTF-8">
        <title>Résultat du vote</title>
    </header>
    <body>
        <form method="post">
            <input type="text" name="get_id" placeholder="ID du vote..."/>
            <input type="submit" name="action" value="Voir résultat" />
            <br/>
            <?php
                session_start();
                if(isset($_POST["get_id"]) or isset($_GET["id"])) {
                $vote_id = 0;
                if(isset($_GET["id"])) {
                    $vote_id = $_GET["id"];
                }
                else {
                    $vote_id = $_POST["get_id"];
                }
                $vote_file = file_get_contents("./Votes/$vote_id.json");
                $result_file = file_get_contents("./Votes_results/{$vote_id}_results.json");
                $vote_data = json_decode($vote_file,true);
                $result_data = json_decode($result_file,true);
                if(!isset($_SESSION['id'])) $_SESSION['id'] = "not_connected"; //A REVOIR
                if($_SESSION['id'] === $vote_data['id_creator'] or $vote_data['id_creator'] === "anonyme"){
                    $check_vote_started = false;
                    for ($i=1; $i < $vote_data["nb_answers"]+1; $i++) { 
                        if($result_data["result_answer_$i"] != 0) {
                            $check_vote_started = true;
                            break;
                        }
                    }
                    if($check_vote_started) {
                        echo "<h1>La question posée était : {$vote_data['question']}</h1>";
                        for ($i=1; $i <$vote_data["nb_answers"]+1 ; $i++) { 
                            echo "<p>La proposition {$vote_data["answer_$i"]} a reçu {$result_data["result_answer_$i"]} vote(s)</p>";
                        }
                    }
                    else {
                        echo "Le vote n'a pas encore reçu de réponse.";
                    }
                }
                else {
                    echo "<h3>Vous ne pouvez pas accéder à ces informations.</h3>";
                }
        }
            ?>
        </form>
    </body>
</html>