<!DOCTYPE html> 
<html>
    <header>
        <title>Login</title>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" type="text/css" href="style_login.css">
    </header>
    <body>
        <div class="content">
            <h1>Login</h1>
            <form method="POST">
                <input type="text" name="log_id" placeholder="Identifiant.."/><br/>
                <input type="password" name="pwd" placeholder="Mot de passe.."/><br/>
                <input class="but" type="submit" name="action" value="Se connecter" /><br/>
                <?php
                    $fp = file_get_contents("users.json");
                    $users_data = json_decode($fp,true);
                    $check = false;
                    if(isset($_POST['action'])){
                        foreach ($users_data as $value) {
                            if($value['id'] === $_POST['log_id'] and $value['pwd'] === $_POST['pwd']) {
                                $check = true;
                                break;
                            }
                        }
                        if($check) {
                            echo "Vous êtes connecté !";
                            session_start();
                            $_SESSION['id'] = $_POST['log_id'];
                            header("Location: http://localhost/Projet/accueil.php");
                        }
                        else {
                            echo "Identifiant/Mot de passe incorrect";
                        }
                    }
                ?>
            </form>
            <h4>Si vous n'est pas inscrit : <a href="http://localhost/Projet/signup.php">s'inscrire</a><h4>
        </div>
    </body>
</html>